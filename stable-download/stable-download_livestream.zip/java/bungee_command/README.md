## EaglercraftBungee

This is regular BungeeCord except it accepts WebSockets instead of raw TCP connections

**To add an animated MOTD: [https://github.com/LAX1DUDE/eaglercraft-motd/](https://github.com/LAX1DUDE/eaglercraft-motd/)**